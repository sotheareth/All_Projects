package com.kongkheang.kmb.api.domain;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity(name = "company")
public class Company extends AuditableBaseModel<Long> {

	private static final long serialVersionUID = -6211531463878007466L;

	@Column(name = "companyName")
	String companyName;

	@OneToMany(cascade = { CascadeType.ALL }, mappedBy = "company")
	// @JoinColumn(name="companyId", nullable = false)
	private Collection<User> users = new ArrayList<User>();

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Collection<User> getUsers() {
		return users;
	}

	public void setUsers(Collection<User> users) {
		this.users = users;
	}

}
