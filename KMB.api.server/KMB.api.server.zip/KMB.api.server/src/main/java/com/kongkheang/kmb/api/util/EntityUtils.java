package com.kongkheang.kmb.api.util;
import org.dozer.CustomFieldMapper;
import org.dozer.DozerBeanMapper;
import org.dozer.classmap.ClassMap;
import org.dozer.fieldmap.FieldMap;
import org.hibernate.collection.internal.AbstractPersistentCollection;

/**
 * Entity utility to copy bean's properties
 * 
 * @author Mr.SAY SEAK LENG
 *
 */
public abstract class EntityUtils {
	
	private static DozerBeanMapper mapper = new DozerBeanMapper();
	
	static {
		mapper.setCustomFieldMapper(new LazyLoadSensitiveMapper());
	}
	
	/**
	 * LazyLoadSensitiveMapper
	 */
	private static class LazyLoadSensitiveMapper implements CustomFieldMapper {
		
		public boolean mapField(Object source, Object destination, Object sourceFieldValue, 
				ClassMap classMap, FieldMap fieldMapping) {
			
		    //if field is initialized, Dozer will continue mapping

			if( sourceFieldValue != null) {
				// Check if field is derived from Persistent Collection
			    if (!(sourceFieldValue instanceof AbstractPersistentCollection)) {
			        // Allow dozer to map as normal
			        return false;
			    }

			    // Check if field is already initialized
			    if (((AbstractPersistentCollection) sourceFieldValue).wasInitialized()) {
			        // Allow dozer to map as normal
			        return false;
			    }
			}

		    return true;
		}
	}
	
	/**
	 * Copy values of Not-Null Properties from source to target
	 * <br/>
	 * It will exclude copying NULL and proxy (lazy-loading) properties of hibernate entity
	 * 
	 * @param source
	 * @param target
	 */
	public static void copyNotNullProperties(Object source, Object destination) {
	    mapper.map(source, destination);
	}
	
	
	
}
