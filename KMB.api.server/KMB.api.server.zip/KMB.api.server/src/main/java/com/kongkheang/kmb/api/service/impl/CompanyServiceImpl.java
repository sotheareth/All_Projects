package com.kongkheang.kmb.api.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kongkheang.kmb.api.dao.CompanyDao;
import com.kongkheang.kmb.api.domain.Company;
import com.kongkheang.kmb.api.domain.request.PageableRequestMessage;
import com.kongkheang.kmb.api.service.CompanyService;

@Service
@Transactional(readOnly = true)
public class CompanyServiceImpl implements CompanyService {
	@Autowired
	private CompanyDao companyDao;

	@Override
	public Company save(Company Company) {
		return companyDao.save(Company);
	}
	
	@Override
	public Page<Company> findCompanys(PageableRequestMessage pageable) {
		Pageable param = pageable.generatePageable();
		return companyDao.findAll(param);
	}
	
}
