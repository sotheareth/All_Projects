package com.kongkheang.kmb.api.util;

public enum Gender {
	M,
	F
}
