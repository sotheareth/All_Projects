package com.kongkheang.kmb.api.test.service;


import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import com.kongkheang.kmb.api.domain.Company;
import com.kongkheang.kmb.api.domain.User;
import com.kongkheang.kmb.api.domain.request.PageableRequestMessage;
import com.kongkheang.kmb.api.domain.response.PageableResponseMessage;
import com.kongkheang.kmb.api.service.CompanyService;
import com.kongkheang.kmb.api.test.AbstractTestCase;
import com.kongkheang.kmb.api.util.Gender;

public class TestCompanyService extends AbstractTestCase {
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Test
	@Transactional
	public void testSave() {
		Session session = sessionFactory.getCurrentSession();
		
		Company company = new Company();
		company.setCompanyName("Dara");
		
		User user1 = new User("test2", Gender.F);
		user1.setCompany(company);
		User user2 = new User("test1", Gender.M);
		user2.setCompany(company);
		
		List<User> users = Arrays.asList(user1, user2);
		company.setUsers(users);
		
//		Company save = companyService.save(company);
		
		session.save(company);
		
		assertNotNull(company);
		prettyPrint(company);
	}
	
	@Test
	public void testFindCompanys() {
		PageableRequestMessage pageable = new PageableRequestMessage(PageableRequestMessage.DEFAULT_OFFSET, 1);
		
		Page<Company> findUsers = companyService.findCompanys(pageable);
		assertNotSame(findUsers.getTotalElements(), 0);
		
		PageableResponseMessage<Company> pageableResponseMessage = new PageableResponseMessage<>(findUsers);
		prettyPrint(pageableResponseMessage);
	}

}